# 261001 · Fokus App 3.5.0 · Paket für Claude Code

Inhalt:
- `261001_FokusApp_Auftrag_3-5-0.md` — Bauauftrag (ohne Handlungsspielraum), zuerst lesen
- `261001_FokusApp_Gedaechtnis_Visualisierung.md` — Definitionen, Logik, Entscheidungen; als Projekt-Gedächtnis ablegen
- `mockups/` — freigegebene Ansichten als Bilder
- `prototyp/` — animierte Belohnungsansicht und Shop als HTML
- `assets/kulissen_ausmal/` — 10 Kulissen zerlegt (farbig, Kanten, Feldkarte, Felddaten). Dateinamen bgNN_* bewusst unverändert, weil die App sie so lädt.

Maßgebliche Quelle der Definitionen: Airtable DFM OS › Wissen_Context › recwXUkjpph7FVr2y · Versionsstand rectwxBNrNDCfRdno.
