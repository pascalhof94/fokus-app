# GEDÄCHTNIS · Fokus App — Visualisierung, Farbe, Ausmalen, Belohnung

Stand 01.10.2026 · gilt ab App 3.5.0 · Quelle: Abstimmung Pascal ↔ Claude (Chat „Visualisierungen standardisieren").
Maßgebliche, fortgeschriebene Fassung: Airtable DFM OS › Wissen_Context › Record `recwXUkjpph7FVr2y` (Versionsstand `rectwxBNrNDCfRdno`). Bei Widerspruch gilt der Record.
Zweck: Dieses Dokument erklärt **warum** die App so aussieht und sich so verhält. Bei künftigen Aufträgen zuerst hier nachlesen. Der konkrete Bauauftrag steht in `261001_FokusApp_Auftrag_3-5-0.md`.

---

## 1 · Wer die App nutzt und wofür

Pascal (GF DFM Europe, Solo-Betrieb) nutzt die Fokus App als Ausführungs-Werkbank für seinen Tag. Airtable ist das Lager, die App führt aus. Leitfrage überall: **„Was bringt als erstes Geld auf das Konto?"**
ADHS-optimiert: dashboard-first, kurze Texte, eine Sache auf einmal. Pascals Kernproblem ist **Aktivierung**, nicht Ausführung — deshalb werden Werkzeuge (kleine Schritte, die zurück auf Kurs bringen) belohnt, und Belohnung muss **sichtbar und aktiv** sein.

**Motivationsmatrix:** x = weg von (links) ↔ hin zu (rechts), y = außen (oben) ↔ innen (unten). Felder: Ablenkung (o. l.), Zustand (u. l.), Werkzeug (o. r.), Ziel (u. r.). Links kostet keine Energie — dort biegt der Tag falsch ab, typischerweise in der Senke zwischen den Fokusphasen.

**Mess-Ebene vs. Spiel-Ebene (strikt getrennt):** Punkte, Rang, Schätzfaktoren rechnen mit Rohpunkten (Mess-Ebene). Münzen, Wohlstand, Farbe, Kulisse, Shop sind Spiel-Ebene und dürfen die Mess-Ebene nie beeinflussen.

---

## 2 · Die vier Ansichten — Leitfrage und Logik

| Ansicht | Rolle | Leitfrage | Horizont | Blickdauer |
|---|---|---|---|---|
| Statusleiste | Puls | Bin ich auf Kurs, jetzt und für den Resttag? | jetzt + Resttag | < 1 Sek. |
| Fokus | Handlung + Überblick | Was tue ich gerade, und wie steht der Tag insgesamt? | laufende Karte + Resttag, je Thema ein Überblick | wenige Sek., bewusst lesen möglich |
| Statistik | Analyse | Wie läuft es im Vergleich, und warum? | heute → Zeitraum → langfristig | bewusst lesen |
| Shop | Belohnung | Was kann ich mir wann leisten — und was male ich aus? | jetzt → Ankunft | bewusst lesen |

**Orientierung (keine harten Regeln):** Was die Statusleiste kurz zeigt, darf anderswo ausführlich stehen. Doppelungen sind erlaubt, wenn die zweite Darstellung **mehr Information** trägt (z. B. Matrix: Statusleiste = Spur 5 Std; Fokus = Feld + Zeit je Feld; Statistik = zusätzlich Spur senkrecht + Tagebuch). Fokus zeigt jedes Thema einmal, Statistik und Shop zeigen Themen in mehreren Sichten. Innerhalb einer Ansicht meist oben „jetzt", unten „langfristig".

---

## 3 · Farbsystem

**Grundidee:** Eine Farbe, eine Bedeutung. Der Linienstil sagt, ob etwas schon passiert ist.

| Rolle | Farbe | Hex |
|---|---|---|
| DFM | Blau (hell) | #3b82f6 (#93c5fd) |
| Privat | Lila (hell) | #a855f7 (#d8b4fe) |
| Gesamt unbewertet | Weiß | #e8e9ec |
| Bewertung (schlecht → gut) | Rot · Orange · Gelb · Gelbgrün · Grün | #f66d6d · #FF9F0A · #f2b84b · #a3d977 · #3ecf8e |
| Vergleich | Grau 80 % (gestern) / 45 % (Ø Wochentag) | #9a9ca2 |
| Über Ziel | Magenta | #FF2D95 |
| Münzen / Spiel | Gold (dunkel) | #d4af37 (#8a6d1f) |
| Jetzt | weißer Punkt mit Hof | #fff |

**Linienstil:** durchgezogen = Ist · gestrichelt = noch nicht passiert (Plan, Prognose) · gepunktet = Grenze (Ziel, Soll).

**Farbträger-Regel:** Vordergrund trägt Familie **oder** Bewertung. Hintergrund trägt **immer** Bewertung oder nichts, nie eine Familienfarbe. Beispiel erlaubt: blaue DFM-Linie auf ampelgetöntem Grund. Verboten: blaue Fläche hinter grüner Linie.

**Wann welcher Farbträger** — welche Frage beantwortet das Diagramm?
1. „Wer, wie verteilt?" → **Familienfarbe** (Punktebar, Tagesverlauf je Familie).
2. „Wie gut gerade, gegen ein Soll?" → **Ampel auf dem Wert** (P/h, Tempo, Prognose). Kurven je Stützpunkt, Zahlen eine Farbe. Referenz immer sichtbar.
3. „In welcher Zone, über Tage?" → **Hintergrund-Bänder**, Linie neutral weiß (Rang, ACWR).

**Hintergrund-Ton ist gewollt** als zweiter Informationskanal (wie Tempopfeile), Deckkraft 14–22 %.

---

## 4 · Diagramm-Katalog und Standards

20 Typen stehen zur Wahl, ausgewählt wird Case für Case: Kurve (Rate) · Kurve (kumuliert) · Fortschrittsbalken · Balkenliste · Kachel/KPI · Skala · Matrix/Streu · Bänder-Verlauf · Bild · Tempopfeil · Album · Punkte-Konsistenz · Kombi-Kachel · Säulen · Gestapelt · Ring · Kalender-Heatmap · Zeitstrahl Plan/Ist · Bullet · Kurve Ist + Prognose.

**Referenz „perfekt":** Glättung des Tempo-Diagramms 3.4.8 — gleitende 60 Min, Stützpunkte alle 30 Min, zentriertes Mittel über 3, `glattPfad()` (Fritsch-Carlson). Dazu **Punktewolke** (graue Rohwerte hinter der Linie) und **getönte Fläche** — Pascals Lieblingsdiagramm.

**Kurven-Zeitachse:** startet am Tagesstart, wächst live, sichtbar bis jetzt + 3 Std, wischbar bis Tagesende, y-Skala passt sich nach dem Wischen an.

**Tempopfeil:** 5 Stufen in der Bewertungsskala, äußere Stufen doppelt (⇈ ↗ → ↘ ⇊).

**Jede Visualisierung wird mit KPIs/Balken unterfüttert.** Statistik-Module: Hauptdiagramm + 3 KPIs, Detail per Tipp aufs Diagramm.

**Beschriftung ist Pflicht** (Pascal hat fehlende Wochentage in der Heatmap bemängelt): Zeitachse, Einheit, Referenzlinien benannt, Heatmap mit Mo–So und KW, „heute" immer markiert.

![Beschriftungsstandard](mockups/261001_FokusApp_Mockup_Beschriftung.png)

---

## 5 · Statusleiste

Drei Zeilen links, rechts eine 148-px-Spalte. Zeile 1: laufende Karte | Gesamtpunkte + Tempopfeil, Outfit-Foto im Ring (füllt sich im Uhrzeigersinn bis zum nächsten Outfit), Mini-Kurve gefärbt nach Gesamtpunkten gegen Soll. Zeile 2: Punktebar DFM | Pv | Soll so breit wie der Kartenkopf. Zeile 3: Akku, Konto (Gold), Tempoleiste so breit wie möglich mit Zahlen, ohne Pfeil. Matrix rechts über Zeile 2 + 3. Der Avatar blinkt, wenn alle Farbtöpfe voll sind (Weg in den Shop).

![Statusleiste](mockups/261001_FokusApp_Mockup_Statusleiste.png)

---

## 6 · Fokus

Reihenfolge: Karten-Kern · Unteraufgaben (Unter-Zähler unten mit Plus und Tick-Zahl; Ticks über dem Tageslimit werden trotzdem gezählt, Zahl in Magenta) · **Tagesketten** (aufklappbar; eine Karte kann in mehreren Ketten stehen; Ketten werden fortlaufend verbessert, bis sie die Realität spiegeln) · **Der Tag** (2×2 Kacheln Prognose, Karte schiebt, Zeit heute, Faktor F; darunter Tempo und Tagesblöcke auf einer Zeitachse — Plan gestrichelt, Ist gefüllt) · **Matrix heute** (Zeit je Feld in den Ecken + Leiste) · Aufgaben-Flow + Belastung · **Karten nach Nutzung der letzten 7 Tage** (ersetzt „Der Tag von oben nach unten"; jede Zeile wie Routinen: ▶/⏸ · Karte · Plus mit Tick-Zahl hinter durchscheinendem Plus · Haken, der bei Abschluss hell wird und die Abschlussroutine auslöst).

![Fokus](mockups/261001_FokusApp_Mockup_Fokus.png)

---

## 7 · Statistik

Die Statistikseite beinhaltet **alles**. Fünf Gruppen: Heute (verdichtet wie Fokus) · Leistung & Rhythmus (Leistung, Konsistenz inkl. **Rang mit Prognose und Historie**, Matrixfaktor, Readiness) · Aufgaben & Routinen · Belastung · **Spiel & Shop** („Wann erreiche ich was?" als Meilenstein-Zeitstrahl).
Der Rang gehört in die Konsistenz, weil er den Median der Tages-P/h über 14 aktive Tage misst — gleichmäßige Leistung, nicht Spitzen.

![Statistik Teil 1](mockups/261001_FokusApp_Mockup_Statistik-Teil1.png)
![Statistik Teil 2](mockups/261001_FokusApp_Mockup_Statistik-Teil2.png)

**Matrixfaktor:** Punkte/h = Basisrate × Matrixfaktor × Geld-Faktor. Faktor hängt nur am Matrixfeld (Ziel 1,0 · Zustand 0,9 · Werkzeug 0,8 · Ablenkung 0). Werkzeuge sind bewusst günstig — ihr Lohn ist der Bewegungsbonus, sonst ließen sie sich „farmen". Bearbeiten = Matrixfeld der Karte ändern (ab jetzt), kein eigener Faktor je Karte.

---

## 8 · Shop und Ausmal-System

**Idee (Pascal):** Belohnung aktiv erleben, indem man die Kulisse hinter dem Avatar ausmalt. Verdienen läuft automatisch, Belohnen ist eine eigene kleine „Hin zu"-Handlung, die nichts vom Konto abzieht.

**Währungen:** Münzen → Shop-Objekte. Wohlstand → Farbe und Kulisse. Beides fließt 1:1 aus denselben Punkten, keiner zieht vom anderen ab.

**Bilder:** Je Kulisse (10) gibt es das Original (Ausgangszustand, mit Feldkanten), eine knallige Fassung (stark gesättigtes Original — so bleiben blaue Fenster, gelbe Fassaden erhalten; flache Einheitsfarben wurden verworfen, weil Beige-Kulissen sonst komplett orange werden) und eine Feldkarte. Felder = zusammenhängende Flächen gleicher Farbe; gleiche Farbe ohne Berührung = getrennte Felder. 24–60 Felder, 10 Farben je Kulisse. Kanten verschwinden, sobald ein Feld ausgemalt ist. Kleine Felder werden per Zoom antippbar.

![Alle Kulissen: blass, halb, fertig](assets/kulissen_ausmal/alle_kulissen_uebersicht.jpg)

**Mechanik:**
- Auswahlstation mit den Farben, die noch offene Felder haben. 5 Töpfe. Ein Topf steht unter einer Farbe und füllt sich mit Wohlstand. Ein Topf hält genau eine Farbe — andere Farbe heißt erst leeren (ausmalen oder auskippen). Der Reiz liegt darin, den richtigen Topf zum Füllen zu wählen.
- Voller Topf → Banner (antippen = Ausmalen, Fokus läuft weiter; wegklicken möglich), nächster leerer Topf rückt nach. Alle voll → Avatar blinkt, Punkte sammeln sich im Tank.
- Ein Feld wird nur vollständig gefüllt. Feldpunkte = Flächenanteil × Kulissenwert. Topf = größtes Feld + 20 %.
- Kulissenwert = Wohlstand-Abstand zur nächsten Kulisse (2500·n^2,3-Treppe). Ausmalen und Freischalten laufen damit gleich schnell: Kulisse 1 ≈ 9.800 P (gut ein Tag), Kulisse 10 ≈ 107.000 P (knapp zwei Wochen).
- Kulisse wechselt erst, wenn die aktuelle fertig **und** die nächste freigeschaltet ist. Dann sind die Töpfe leer, Fassung und Farben neu.
- Nach dem Update werden Münzen, Wohlstand, Shop und Kulissen auf null gesetzt (Rang und Outfit-Historie bleiben).

![Shop Übersicht](mockups/261001_FokusApp_Mockup_Shop-Uebersicht.png)
![Malmodus](mockups/261001_FokusApp_Mockup_Shop-Malmodus.png)

---

## 9 · Belohnungsansicht

Nach jeder abgeschlossenen Aufgabe (nach der Matrix-Abfrage), nach dem Pausieren einer Routine mit Uhr und beim Tagesziel eines Counters. Bei jedem einzelnen Tick nur eine Kurzform (≈ 1 s, fliegende Punkte/Farbe/Münze), damit der Fluss nicht bricht.
Inhalt animiert, Schritt für Schritt: Punkte (zählt hoch, Balken gegen Tagesziel) · Zeit · Akku · Tempo gegen Tag · Farbe tropft in den Topf · Münzen fliegen ins Konto · Outfit wechselt animiert · weitere Infos. Balken füllen sich animiert in passenden Verläufen. Überspringen per Doppeltipp oder großem Knopf unten.

![Belohnung Anfang](mockups/261001_FokusApp_Mockup_Belohnung-Start.png)
![Belohnung Ende](mockups/261001_FokusApp_Mockup_Belohnung-Ende.png)

---

## 10 · Arbeitsweise mit Pascal (für künftige Aufträge)
- Aufträge an Claude Code werden **ohne Handlungsspielraum** spezifiziert; frühere Läufe lieferten sonst Unerwartetes.
- Werte (Ziele, Faktoren, Einstellungen) fließen per Import-Paket in die App; ein Bauauftrag ist nur nötig, wenn sich **Verhalten** ändert.
- Methodik- und Korrekturhinweise gehören nie in Deliverables.
- Nicht raten: Was nicht im Code oder in Airtable nachgesehen ist, wird als Annahme markiert.

## 11 · Entscheidungsprotokoll (01.10.2026)
Farbrollen und Farbträger-Regel · Hintergrund-Ton als zweiter Kanal · Punktewolke Standard · Kurven-Zeitachse jetzt + 3 Std · Tempopfeil 5-stufig · Statusleiste verdichtet · Fokus-Aufbau inkl. Tagesketten und Kartenliste · Statistik in 5 Gruppen, Detail per Tipp · Rang in Konsistenz · Matrixfaktor-Modul, Bearbeiten = Matrixfeld · Shop Übersicht + Malmodus · Ausmal-System (Töpfe, Tank, Station) · Wohlstand → Farbe/Kulisse, Münzen → Shop · Kulissenwechsel bei fertig + freigeschaltet · Reset nach Update · Belohnungsansicht + Kurzform bei Ticks.
