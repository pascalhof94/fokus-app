from PIL import Image, ImageFilter, ImageEnhance
import numpy as np, json, os
from scipy import ndimage
from sklearn.cluster import KMeans
OUT='/mnt/user-data/outputs/kulissen_ausmal'; os.makedirs(OUT,exist_ok=True)
K=10; MINPX=2800   # bei 1200x669 (entspricht 700 px bei 600 Breite)
def schwelle(n): return round(2500*n**2.3)
uebersicht=[]
for n in range(1,11):
    nm=f'bg{n:02d}'
    orig=Image.open(nm+'.jpg').convert('RGB'); W,H=orig.size
    sm=orig.filter(ImageFilter.MedianFilter(9))
    a=np.asarray(sm).reshape(-1,3).astype(float)
    km=KMeans(n_clusters=K,n_init=4,random_state=1).fit(a[::13])
    lab=km.predict(a).reshape(H,W)
    reg=np.zeros((H,W),np.int32); cnt=0
    for c in range(K):
        r,nn=ndimage.label(lab==c); r[r>0]+=cnt; reg+=r; cnt+=nn
    for _ in range(4):
        sizes=np.bincount(reg.ravel(),minlength=reg.max()+1)
        kl=np.where((sizes>0)&(sizes<MINPX))[0]
        if not len(kl): break
        objs=ndimage.find_objects(reg)
        for i in kl:
            sl=objs[i-1]
            if sl is None: continue
            sl=tuple(slice(max(0,s.start-2),s.stop+2) for s in sl)
            sub=reg[sl]; m=sub==i
            if not m.any(): continue
            ring=ndimage.binary_dilation(m)&~m; nb=sub[ring]
            if nb.size: sub[m]=np.bincount(nb).argmax()
    ids=np.unique(reg)
    remap=np.zeros(reg.max()+1,np.int32); remap[ids]=np.arange(1,len(ids)+1); reg=remap[reg]
    nF=len(ids)
    viv=ImageEnhance.Color(orig).enhance(3.0); viv=ImageEnhance.Contrast(viv).enhance(1.25); viv=ImageEnhance.Brightness(viv).enhance(1.05)
    viv=viv.filter(ImageFilter.MedianFilter(3)); va=np.asarray(viv)
    edge=np.zeros((H,W),bool)
    edge[:-1,:]|=reg[:-1,:]!=reg[1:,:]; edge[:,:-1]|=reg[:,:-1]!=reg[:,1:]
    edge=ndimage.binary_dilation(edge,iterations=1)
    o=np.asarray(orig).copy()
    # Dateien
    viv.save(f'{OUT}/{nm}_farbig.jpg',quality=90)
    kb=o.copy(); kb[edge]=(20,20,24); Image.fromarray(kb).save(f'{OUT}/{nm}_blass_kanten.jpg',quality=90)
    km_png=Image.fromarray((edge*255).astype(np.uint8)); km_png.save(f'{OUT}/{nm}_kanten.png',optimize=True)
    Image.fromarray(reg.astype(np.uint8)).save(f'{OUT}/{nm}_feldkarte.png',optimize=True)
    # Farben und Felder
    farben=[]
    for c in range(K):
        m=lab==c
        col=va[m].mean(0) if m.any() else np.zeros(3)
        farben.append({'farbe':c,'hex':'#%02x%02x%02x'%tuple(int(x) for x in col)})
    sizes=np.bincount(reg.ravel(),minlength=nF+1)
    objs=ndimage.find_objects(reg)
    gesamt=int(sizes[1:].sum()); groesst=int(sizes[1:].max())
    wert=schwelle(n+1)-schwelle(n) if n<10 else schwelle(10)-schwelle(9)
    felder=[]
    for f in range(1,nF+1):
        sl=objs[f-1]; m=reg[sl]==f
        c=int(np.bincount(lab[sl][m]).argmax())
        felder.append({'feld':f,'farbe':c,'flaechePx':int(sizes[f]),'anteil':round(sizes[f]/gesamt,6),
            'bbox':[sl[1].start,sl[0].start,sl[1].stop,sl[0].stop]})
    d={'kulisse':n,'datei':f'img/{nm}.jpg','breite':W,'hoehe':H,'anzahlFarben':K,'anzahlFelder':nF,
       'groesstesFeldPx':groesst,'topfFassungPx':int(round(groesst*1.2)),
       'hinweisPunkte':'Feldpunkte noch offen: Vorschlag anteil x Kulissenwert','kulissenwertVorschlag':wert,
       'farben':farben,'felder':felder}
    json.dump(d,open(f'{OUT}/{nm}_felder.json','w'),ensure_ascii=False,indent=1)
    # Vorschau: blass | halb | farbig
    sizesF=sizes[1:]; order=np.argsort(-sizesF)+1; halb=set(order[::3].tolist())
    hm=np.isin(reg,list(halb)); h=o.copy(); h[hm]=va[hm]; h[edge&~hm]=(20,20,24)
    pv=Image.new('RGB',(W,H*3+16)); pv.paste(Image.fromarray(kb),(0,0)); pv.paste(Image.fromarray(h),(0,H+8)); pv.paste(viv,(0,2*H+16))
    pv.resize((W//2,(H*3+16)//2)).save(f'{OUT}/{nm}_vorschau.jpg',quality=85)
    uebersicht.append((n,nF,groesst,wert))
    print(nm,'Felder',nF,'groesstes',groesst,'Topf',int(groesst*1.2),'Kulissenwert',wert)
