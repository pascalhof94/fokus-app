# AUFTRAG an Claude Code — Fokus App 3.5.0 „Visualisierungen standardisieren + Ausmalen + Belohnungsansicht"

Stand: 01.10.2026 · Basis: LIVE 3.4.8 (Commit 1469208, Datenvertrag 2.0) · Ziel: **3.5.0**, **Datenvertrag 2.1**
Repo: `pascalhof94/fokus-app`, Datei `neu.html`. Begleitdokument: `261001_FokusApp_Gedaechtnis_Visualisierung.md` (Kontext und Begründungen — bitte als Projekt-Gedächtnis ablegen).
**Maßgebliche Quelle der Definitionen ab jetzt:** Airtable, Base DFM OS (`appyHNK8rnpMnKwny`), Tabelle Wissen_Context, Record `recwXUkjpph7FVr2y` „Fokus App — Visualisierungs- und Farbstandard …“. Versionsstand: Record `rectwxBNrNDCfRdno`. Bei Widerspruch zwischen diesem Paket und dem Airtable-Record gilt der Record.

---

## 0 · Arbeitsregeln für diesen Auftrag (verbindlich)

1. **Kein Handlungsspielraum.** Alles, was hier steht, wird genau so umgesetzt. Wo etwas nicht beschrieben ist, bleibt der Code unverändert. Gibt es einen Widerspruch zwischen Text und Mockup, gilt der **Text**. Bei echten Lücken: **nicht raten**, im Abschlussbericht unter „Offene Fragen" melden und die Stelle unverändert lassen.
2. **Nicht anfassen:** Punkteformeln (außer der in §8 beschriebenen Matrixfeld-Änderung), Sync-Logik, Import-Gate, Tagesabschluss-Ablauf, Routinen-System, Suche, Einstellungen-Ansicht, `karteVisStil`/`karteVisKlasse` (Kartenvisuals in der Suche), Kulissen-Assets in `img/kulissen/` (nicht neu zerlegen, nicht nachbearbeiten).
3. **Reihenfolge der Umsetzung:** §1 Farbsystem → §2 Diagramm-Standards → §3 Statusleiste → §4 Fokus → §5 Statistik → §6 Shop + Ausmalen → §7 Belohnungsansicht → §8 Matrixfaktor → §9 Datenvertrag 2.1 + Reset → §10 Prüfpunkte → §11 Abnahme.
4. **Version:** `APP_VERSION = '3.5.0'`, Datenvertrag `2.1`. Testdateien auf 3.5.0 nachziehen (stehen noch auf 3.4.0).
5. **Abschlussbericht:** je Abschnitt ✅ umgesetzt · ⚠️ Abweichung (mit Grund) · ❓ offene Frage. Commit-Hash nennen.
6. Die Mockups im Ordner `mockups/` zeigen **Beispieldaten**. Maße, Reihenfolge, Farben und Elemente sind verbindlich, die Zahlen nicht.

---

## 1 · Farbsystem

### 1.1 Konstanten (neu, ersetzt alle bisherigen Paletten)

```js
const FARBE = {
  GRUEN:'#3ecf8e', GELBGRUEN:'#a3d977', GELB:'#f2b84b', ORANGE:'#FF9F0A', ROT:'#f66d6d',
  BLAU:'#3b82f6', BLAU_HELL:'#93c5fd', LILA:'#a855f7', LILA_HELL:'#d8b4fe',
  WEISS:'#e8e9ec', GRAU:'#9a9ca2', UEBER:'#FF2D95', GOLD:'#d4af37', GOLD_DUNKEL:'#8a6d1f',
  BAHN:'#1c1f25', KARTE:'#121418', KACHEL:'#1a1d22', LEER:'#262a32', RASTER:'rgba(255,255,255,.08)'
};
const BEWERTUNG = [FARBE.ROT, FARBE.ORANGE, FARBE.GELB, FARBE.GELBGRUEN, FARBE.GRUEN]; // schlecht → gut
```

### 1.2 Rollen — jede Farbe hat genau eine Bedeutung

| Rolle | Farbe | Wofür | Wofür NIE |
|---|---|---|---|
| Familie DFM | `BLAU` (hell: `BLAU_HELL`) | alles, was DFM-Punkte/-Karten meint | Vergleich, „gestern" |
| Familie Privat | `LILA` (hell: `LILA_HELL`) | alles Private | Rang |
| Gesamt (unbewertet) | `WEISS` | Summen ohne Bewertung | — |
| Bewertung/Ampel | `BEWERTUNG` (5 Stufen) bzw. `diaAmpel` (stetig) | Wert gegen Soll/Referenz | Familien, Dinge/Marken |
| Vergleich | `GRAU` 80 % (gestern) · `GRAU` 45 % (Ø Wochentag) | Referenzlinien | Ist-Werte |
| Plan / Prognose | Familienfarbe bzw. `WEISS`, **gestrichelt** `4 3` | was noch nicht passiert ist | Ist |
| Ziel-Grenze | `WEISS` 50–70 %, **gepunktet** `2 3`, 1–1,5 px | Ziel-/Soll-Marken | — |
| Über Ziel | `UEBER` | nur Überschreitung eines Ziels/Limits | sonst nichts |
| Spiel: Münzen | `GOLD` (Verlauf `GOLD_DUNKEL`→`GOLD`) | Konto, Kauf-Marken, Münz-Balken | Bewertung |
| Hintergrund-Ton | `BEWERTUNG`/`diaAmpel` bei 14–22 % Deckkraft | zweiter Informationskanal | Familienfarbe |
| Achsen/Text | `GRAU` Text, `RASTER` Linien | Beschriftung | — |
| Jetzt | Punkt r=3 `#fff` + Hof r=6 `#fff` 20 % + senkrechte Linie `#fff` 35 % 1 px | Zeitpunkt jetzt | — |

### 1.3 Farbträger-Regel (verbindlich)
- **Vordergrund** (Linie, Balken, Zahl) trägt **entweder** Familie **oder** Bewertung — nie beides auf demselben Element.
- **Hintergrund** trägt **immer** Bewertung oder nichts — **nie** eine Familienfarbe.
- Vergleich (grau), Jetzt (weiß), Ziel-Grenze (weiß gepunktet) sind in jedem Modus erlaubt.

### 1.4 Diskrete Bewertungsskala (Heatmap, Bänder-Kacheln, Pfeile)
`r = Ist ÷ Soll`: **≥ 1,00** GRUEN · **≥ 0,90** GELBGRUEN · **≥ 0,80** GELB · **≥ 0,75** ORANGE · **< 0,75** ROT · kein Wert/Urlaub `LEER`.
Stetige Färbung (Kurven, Zahlen): `diaAmpel()` bleibt unverändert (≥1 grün · 0,9 gelb · ≤0,75 orange, linear dazwischen).

### 1.5 Migration der alten Paletten
| Alt | Neu |
|---|---|
| `DIA_FARBE` | bleibt als Alias, Werte aus `FARBE` (Schlüssel `gruen, gelb, orange, rot, blau, lila, grau, ueber, BLAU_HELL, LILA_HELL, GELB_HELL`); `GELB_HELL` wird nirgends mehr verwendet |
| `AMPEL_FARBE` | Werte ersetzen: gruen→GRUEN, gelb→GELB, orange→ORANGE, rot→ROT, grau→GRAU (helle Zweitwerte = Hauptwert mit 45 % Deckkraft) |
| `SPIEL_FARBE.muenzen` | `[GOLD, GOLD_DUNKEL]` |
| `SPIEL_FARBE.rang` | entfällt in Diagrammen (Rang nutzt Bänder, §5) |
| `SPIEL_FARBE.kulisse` | entfällt (Kulisse §6) |
| `DIA_LINIE.alle` (Gesamt gelb) | `WEISS`; Linienstile siehe §2.1 (gestrichelt/gepunktet für Vergleich entfallen) |
| `MX_FARBE` in Diagrammen (`matrixVerlaufSvg`, `stMatrixSpur`, Legenden) | entfällt; Spur-Punkte `#fff`, Deckkraft nach Alter 20 %→100 % |
| `rangFarbe()`, `anteilFarbe()` mit `#fca5a5`/`#6ee7a8` | auf `BEWERTUNG` umstellen (stetig zwischen den 5 Stufen mischen mit `diaMisch`) |
| `#statusbar .sb-bar .ist.dfm/.privat` Verläufe | flächig `BLAU` / `LILA` |
| `.sollmark` rot | `WEISS` gepunktet |
| `ts-p` drei Punkte rot/gelb/grün | siehe §3 |
| Plan-Balken Karte grün/gelb/rot (`fokusPlanbar`) | erhalten = Familienfarbe, offen = Familienfarbe 25 %, über Plan = `UEBER`, Kauf-Marke = `GOLD` |
| Privat-Label in Gelb (`fbWoIchStehe`) | entfällt mit dem Block (§4) |

**Abnahme §1:** Suche im Code nach `#fca5a5`, `#6ee7a8`, `#f8d68f`, `#22d3ee`, `#6dd3e0`, `#f08c4b`, `#c23a3a`, `#4f8ef7` in Diagramm-Code ergibt 0 Treffer. Keine Familienfarbe als Hintergrundfläche eines Diagramms.

---

## 2 · Diagramm-Standards (gelten für jedes Diagramm)

### 2.1 Kurven
- **Glättung** (Vorbild Tempo-Diagramm 3.4.8): Wert = gleitende 60 Min; Stützpunkte alle 30 Min plus „jetzt"; zentriertes Mittel über 3 Stützpunkte; Pfad über `glattPfad()` (Fritsch-Carlson). Tageswert-Kurven (je Tag ein Punkt): gleitendes Mittel über 3 Tage, Pfad über `glattPfad()`.
- **Linien:** heute/Ist 2,5 px · Vergleich 1,5 px · Plan/Prognose 1,5 px gestrichelt `4 3` · Ziel 1 px gepunktet `2 3`.
- **Punktewolke** (Typ-Liste unten): Rohwerte hinter der geglätteten Linie, Kreis r=1,5, `GRAU`, Deckkraft 45 %, nie in Ampel.
- **Fläche unter der Ist-Kurve:** Ampel-Verlauf je Stützpunkt bei 22 % (wie 3.4.8).
- **Zeitachse Tagesdiagramme:** x beginnt am Tagesstart (`S.tag.startTs`), Kurve wächst live nach rechts. Sichtbar ist **Tagesstart bis jetzt + 3 Std**. Waagerecht wischbar bis Tagesende (`diaTagesEndeMs()`). Nach dem Wischen wird die y-Skala nach 150 ms neu berechnet, die x-Achse (Fensterbreite) bleibt. y-Beschriftung sticky. **Gilt jetzt auch für das Tempo-Diagramm** (`heuteGegenTypischHtml`), das bisher den ganzen Tag fest zeigte.
- Punktewolke ist Pflicht bei: Tempo, Tagesverlauf, Matrix-Spur, Leistung, Konsistenz, Readiness, Belastungssteuerung, Rang, Kurven in Kombikacheln (wenn Platz ≥ 60 px Höhe).

### 2.2 Balken
- Bahn `BAHN`, Radius = halbe Höhe. Füllung in Rollenfarbe. Prognose/Plan-Verlängerung = Rollenfarbe 25–30 % Deckkraft.
- Markierungen als senkrechte Striche in Rollenfarbe: Ziel `WEISS` gepunktet, Vergleich `GRAU` 2 px, Kauf-Schwelle `GOLD` 1,5 px, Viertel-Striche `GRAU` 40 % 1 px.
- Überschreitung eines Ziels: Anteil über Ziel in `UEBER`.

### 2.3 Tempopfeil (5 Stufen)
`r = Tempo(letzte 60 Min) ÷ Tempo(die 60 Min davor)`, beide gleitend wie §2.1:
**≥ 1,25** ⇈ GRUEN (Doppelpfeil) · **≥ 1,05** ↗ GELBGRUEN · **> 0,95** → GELB · **> 0,75** ↘ ORANGE · **≤ 0,75** ⇊ ROT (Doppelpfeil). Weniger als 15 Min Messzeit in einem der Fenster → kein Pfeil. Zeichnung als SVG, 12×12 px, Strich 1,8 px, runde Enden.

### 2.4 Hintergrund-Ton
In jedem Diagramm erlaubt. Drei Formen: (a) Fläche unter der Kurve, (b) Zonen-Bänder, (c) Flächenverlauf (Matrix ROT→GRUEN). Deckkraft 14–22 %.

### 2.5 Beschriftung (Pflicht)
- Zeitachse: Uhrzeit bei Tagesdaten; Wochentag-Kürzel (Mo…So) bei ≤ 14 Tagen; darüber `TT.MM.` am Wochenanfang. „jetzt"/„heute" immer beschriftet, in `WEISS`.
- Wertachse: Einheit oben links (`P/h`, `P`, `%`), 2–3 Rasterlinien mit Wert.
- Referenzlinien tragen ihren Namen rechts am Linienende („Median", „Ziel", „Ø Do").
- Heatmap: Spaltenkopf Mo…So, Zeilen „KW nn", heute weiß umrandet, darunter Farbskala mit „< 75 %" … „≥ 100 % Ziel" und „kein Tag".
- Säulen: Kategorie unter jeder Säule, Wert über der heutigen Säule.
- Bänder: Schwellen rechts. Streu: beide Achsen benannt. Matrix: vier Feldnamen in den Ecken.
- Vorlage: `mockups/261001_FokusApp_Mockup_Beschriftung.png`.

### 2.6 Ringe
Ringe nur noch für: Outfit-Fortschritt (Statusleiste, Shop) und Karten-Zeit (Fokus). Alle anderen Fortschritts-Ringe (`fbRing` in Anteil am Tagessoll, Tagesziel-Ring, Münzen-Ring, „Als Nächstes im Shop") werden Balken nach §2.2.

**Abnahme §2:** Jedes Diagramm in Fokus, Statistik, Shop hat Achsen-/Kategorien-Beschriftung nach §2.5. Tempo-Diagramm scrollt wie der Tagesverlauf. Kein Fortschrittsring außerhalb von §2.6.

---

## 3 · Statusleiste (`renderStatusbar`, Markup `#statusbar`, Kopf `tb-*`) — Vorlage `mockups/261001_FokusApp_Mockup_Statusleiste.png`

### 3.1 Raster
CSS-Grid, 2 Spalten: links `minmax(0,1fr)`, rechts **148 px**; 3 Zeilen; Abstand 8 px.
- **Zeile 1 links:** Pause/Play-Knopf (34×34, Radius 9, Familienfarbe der laufenden Karte) · Kartentitel (eine Zeile, Ellipse) · darunter Kasten mit Uhr (`WEISS`) und Punkten der Karte (Familienfarbe).
- **Zeile 1 rechts** (148 px, drei Elemente nebeneinander): Gesamtpunkte heute (16 px, `WEISS`) mit **Tempopfeil** §2.3 rechts daneben, darunter „heute · P" · Outfit-Foto 34×34 im **Ring** (3 px, Bahn `GRAU` 30 %, Füllung `GRUEN` im Uhrzeigersinn ab 12 Uhr = `outfitFortschritt().frac`; voll = nächstes Outfit) · Mini-Kurve 44×28 (bestehende `renderAmpelKurve`): Ist-Linie in `diaAmpel(punkteHeute, sollBisJetzt)`, Fortsetzung bis Tagesende gestrichelt `WEISS` 70 %, Jetzt-Punkt.
- **Zeile 2 links:** „DFM `n`" (`BLAU`) · Punktebar · „Pv `n`" (`LILA`) · „Soll `n`" (`WEISS`).
- **Zeile 3 links:** Grid `44px 52px 1fr`: AKKU (Wert in `diaAmpel`-Logik wie bisher) · KONTO (Wert `GOLD`, ohne Leiste, ohne „Kulisse …") · TEMPO (Kopf links „TEMPO", rechts „`tempoSchnitt` → `tempoZiel`", Schnitt in Ampelfarbe, ohne Pfeil) mit Skala darunter über die volle Restbreite.
- **Zeilen 2+3 rechts:** Matrix-Kachel (5 Std, `matrixVerlaufSvg` klein) über beide Zeilen, 148 px breit, Höhe = Zeile 2+3. Endpunkt `#fff` statt grün.

### 3.2 Punktebar
Breite = Tagesziel. DFM flächig `BLAU` von links, Privat flächig `LILA` von rechts. **Neu:** Prognose bis Tagesende je Familie als Verlängerung in Familienfarbe 30 % (DFM: `tempoSchnitt`-Anteil DFM × `stundenRest`; Privat analog). Viertel-Striche `GRAU` 40 %. Grenze DFM-/Privat-Ziel (`sBarSollMark`) `WEISS` gepunktet. Kauf-Schwellen (`sBarMarks .mark`) `GOLD`. Über Ziel `UEBER`.

### 3.3 Tempo-Skala (`tempoSkalaHtml`)
Balken 0…`tempoSchnitt` in `diaAmpel(tempoSchnitt, tempoZiel)`. Nötiges Tempo `tempoZiel` = senkrechte Marke `WEISS` gepunktet. Schnitt = Balkenende mit Jetzt-Punkt `#fff` r=3,8. Laufende Karte = Punkt r=3,2 in **Familienfarbe der Karte**. Die drei farbigen Punkte rot/gelb/grün entfallen.

### 3.4 Uhr-Farbe
Karten-Uhr im Kopf `WEISS` (bisher cyan).

**Abnahme §3:** Layout deckt sich mit `mockups/261001_FokusApp_Mockup_Statusleiste.png` bei 375 und 430 px Breite ohne Umbruch. Avatar-Ring füllt sich mit `outfitFortschritt()`. Avatar **blinkt** (Ring pulsiert 1,2 s, `GRUEN`↔`WEISS`), solange alle 5 Farbtöpfe voll sind (§6.4).

---

## 4 · Fokusansicht (`renderFokus`) — Vorlage `mockups/261001_FokusApp_Mockup_Fokus.png`

### 4.1 Soll-Reihenfolge (von oben)
1. **Karten-Kern** (bestehend, verdichtet): Titel · Ring 76 px (Zeit-Bogen in Familienfarbe, über Plan `UEBER`; **ohne** Outfit-Foto in der Mitte, dort Restminuten + „Min Rest") · rechts 2×2-KPIs aus `fokusKpis` (P/Std in `diaAmpel`, Punkte x/Plan, Minuten, Schritte x/y) · darunter Plan-Balken (`fokusPlanbar`, Farben nach §1.5) · Bedienleiste ⏸ ✎ ⏭ … ✓ (✓ nur Aufgaben, wie bisher).
   **Entfällt:** `tstats`-Reihe (Akku · Pkt heute · Zeit heute), `#tTempo` Tempo-Leiste groß.
2. **Unteraufgaben** (`fokusSubsHtml`): wie bisher. **Neu:** Unter-Zähler (`istUnterZaehler`) stehen **unten im selben Feld** als Zeile „Titel · Limit n" + Tick-Knopf (Plus 30 px `WEISS` 18 % Deckkraft, darüber die Tick-Zahl heute 14 px mono). Ticks über dem Tageslimit werden **gezählt und gebucht** (wie bisher nach dem Limit: 0 P, Zeit zählt); die Zahl erscheint dann in `UEBER`.
3. **Tagesketten** (neu, aufklappbar, Standard zu): Kopf „Tagesketten ▾" + rechts „Karte in x von y". Aufgeklappt: Chips aller Ketten „Name · Anzahl Karten"; Ketten, in denen die aktuelle Karte steckt, mit `BLAU`-Rand und -Text (Familienfarbe der Karte). Tipp auf Chip wählt die Kette; darunter die Reihenfolge der gewählten Kette als Text, aktuelle Karte fett `WEISS`. Datenmodell §9.3.
4. **Der Tag:** 2×2-Kombikacheln **Tagesprognose** (Wert in `diaAmpel(prognoseHeute, zielHeute)`, „fehlen n"/„Ziel ✓", Mini-Kurve Ist + gestrichelte Prognose + Ziel-Linie) · **Diese Karte schiebt** (+P, „= x % vom Tagesziel", Mini-Balken Rest `GRAU` 50 % + Karte in Familienfarbe) · **Zeit heute** (Ist/Plan, Balken `WEISS`) · **Faktor F** (Wert in Ampel wie bisher + Tempopfeil-Logik auf F-Verlauf der letzten 60 Min, „Outfit n → n+1 bei x"). Darunter **„Tempo und Blöcke"**: Tempo-Kurve nach §2.1 (heute Ampel, gestern `GRAU` 80 %, Ø letzte 2 gleicher Wochentag `GRAU` 45 %) und darunter auf **derselben x-Achse** die Tagesblöcke (Typ Zeitstrahl): Plan = gestrichelter Umriss in Familienfarbe (aus `tagesRahmen`/Tagesverlauf-PLAN), Ist = gefüllt in Familienfarbe (aus Sitzungen), Blocknamen 9 px über der Plan-Reihe, Jetzt-Linie durchgehend. Legende darunter: „Plan gestrichelt · Ist gefüllt · heute n P/h · gestern n · Ø Wd n".
5. **Matrix heute:** Matrix 340×96 (Flächenverlauf ROT→GRUEN 22 %/8 %/22 %), Ecken „Ablenkung h:mm", „Werkzeug h:mm", „Zustand h:mm", „Ziel h:mm" (Zeit je Feld aus `fbGrosseMatrix().zeit`), Spur weiß nach Alter, Jetzt-Punkt r=4,5. Darunter Leiste 8 px: Zeitanteile ROT (Ablenkung) · ORANGE (Zustand) · WEISS (Werkzeug) · GRUEN (Ziel); Text „Zeit je Feld als Leiste · unbekannt h:mm". Tipp in ein Feld = Tagebuch-Eintrag (bestehendes Verhalten von `fbGrosseMatrix({klick:true})`).
6. **Aufgaben-Flow heute** + **Belastung ACWR** als 2 Kacheln nebeneinander: Flow = neu/erledigt/geschoben/netto (Werte aus `reinRausTagHtml`-Datenquelle, nur DFM), Belastung = ACWR-Wert in `acwrStufe`-Farbe + Bullet-Balken auf Bändern (ORANGE <0,8 · GRUEN 0,8–1,3 · GELB 1,3–1,5 · ROT >1,5) + „0,8 · 1,3 · 1,5".
7. **Karten · meistgenutzt letzte 7 Tage** (ersetzt `zeitstrahlHtml()` „Der Tag von oben nach unten"; `abhakLeisteHtml()` entfällt hier ebenfalls).
   - Menge: alle Karten auf dem Gerät (Werkbank), Status offen oder heute erledigt; nie archiviert.
   - Sortierung: Anzahl Buchungsereignisse (Sitzungen + Ticks + Abhaken) der letzten 7 App-Tage inkl. heute, absteigend; Gleichstand → zuletzt genutzt zuerst.
   - Zeile (Grid `34px 1fr 40px 34px`, linker Rand 3 px Familienfarbe): ▶/⏸ (`uhrLaeuftAuf`) · Titel + Meta „n× · DFM|Privat|Limit n" · Tick-Knopf wie §4.1.2 mit Zahl der Ticks heute (`UEBER` über Limit) · ✓-Kreis 34 px (offen: Rand `#2a2d33`; erledigt: Füllung `GRUEN`, Haken dunkel). Laufende Karte: Zeilen-Hintergrund `#16203a`, Play-Knopf in Familienfarbe.
   - Verhalten Tick und ✓: siehe §12 Festlegungen F1/F2.

### 4.2 Entfällt aus der Fokusansicht
`fbWasDieseKarte` (Block „Was diese Karte einbringt"), `fbWoIchStehe` (inkl. Tagesziel-Ring, DFM-/Privat-Balken, Outfit-Kachel, Faktor-Kachel, Tagesverlauf kumuliert, ACWR-Modul in Langform), `fbWasIchBewege` (ersetzt durch 4.1.5 und 4.1.4), Bewegungsbonus-Kachel → erscheint als Zusatzzeile unter den 2×2-Kacheln in 4.1.4, nur wenn `k.bewegungsBonus > 0`: „Bewegungsbonus heute +n von m P" mit Balken `GRUEN`.

**Abnahme §4:** Reihenfolge exakt 1–7. Kein Outfit-Foto im Fokus. Unter-Zähler zählen über das Limit und zeigen die Zahl in `UEBER`. Ketten aufklappbar, Mehrfach-Zugehörigkeit sichtbar. Tempo und Blöcke teilen eine x-Achse und scrollen gemeinsam.

---

## 5 · Statistik (`renderStatistikBody`, `STAT_MODULE`, `STAT_DETAIL`) — Vorlagen `mockups/261001_FokusApp_Mockup_Statistik-Teil1.png`, `statistik_2.png`, `beschriftung.png`

### 5.1 Grundaufbau
- Fünf **Gruppen** mit Überschrift (13 px, 500): **1 Heute** · **2 Leistung & Rhythmus** · **3 Aufgaben & Routinen** · **4 Belastung** · **5 Spiel & Shop**.
- **Filter** (Zeitraum 7 T / 28 T / 90 T · Domäne Alle/DFM/Privat · Art wie bisher) steht **über Gruppe 2** und gilt für Gruppen 2–5. Gruppe 1 ignoriert den Filter. (Bestehende `analyseFenster`, `S.ui.analyseDomain`, `analyseArt` weiterverwenden.)
- Jedes **Modul** = Karte mit Kopf (Titel links, ▾/▴ rechts) · **Hauptdiagramm** · darunter **3 KPI-Kacheln** (Grid 3 Spalten, Wert 13 px mono 500, Label 10 px `GRAU`). **Tipp auf das Hauptdiagramm** (oder ▾) klappt den Detailbereich auf (gestrichelte Trennlinie, weitere Darstellungen und KPIs). Zustand je Modul in `S.ui.statOffen[id]` (nicht exportiert).
- `statistik.reihenfolge` / `.ausgeblendet` arbeiten mit den neuen Modul-IDs aus 5.2.

### 5.2 Module — Hauptdarstellung · KPIs · Detail (aufgeklappt)
Alle bisherigen Inhalte bleiben erhalten, nur neu gruppiert.

| Gruppe | ID | Hauptdarstellung | 3 KPIs | Detail (aufgeklappt) | Quelle (bestehend) |
|---|---|---|---|---|---|
| 1 | `tag` | wie Fokus 4.1.4 (2×2 + Tempo und Blöcke) | — | Tagesverlauf kumuliert je Familie (`belTagesDiagramm`, Linien BLAU/LILA/WEISS, Plan gestrichelt, Ø Wd grau) · Kennzahlen Schiebe-Quote, Überfällig jetzt, Ø Start, Ø Ende | `heuteGegenTypischHtml`, `anModVerhalten` |
| 1 | `matrixHeute` | wie Fokus 4.1.5 | — | Matrix-Spur senkrecht (`matrixVerlaufSvg`) mit Tipp-Info · Tagebuch-Rauten · Belastung heute (Zeit links %, Werkzeuge nötig, Akku-Gefälle %/h) | `stMatrixTag`, `stMatrixSpur`, `stBelastung` |
| 1 | `heuteKurz` | 2 Kacheln wie Fokus 4.1.6 | — | Tipp springt zu `flow` bzw. `acwr` | — |
| 2 | `leistung` | P/h je Tag: Punktewolke + geglättete Linie + Ampel-Fläche gegen Rang-Schwelle | Median P/h · Pfeil + % vs. Vorperiode · Bestwert | Zielerreichung je Domäne (Säulen je Tag BLAU/LILA gegen Ziel-Linie) · Tagespunkte 28 Tage (bisher „Entwicklung") | `anModLeistung`, `stEntwicklung` (ohne Rang/Kleidung/Konto/Kulisse) |
| 2 | `konsistenz` | Tagespunkte um den Median: Punkte je Tag in `BEWERTUNG` (r = Tag ÷ Tagesziel), Punktewolke, Linie, Median-Linie grau gestrichelt, Ziel-Linie weiß gepunktet, Bänder GRUEN/GELB/ROT 12–14 % | Werktage im Ziel x/y · Streuung ±% (MAD ÷ Median) · längste Serie (Tage ≥ Ziel) | Heatmap 4 Wochen (§2.5) · Wochentagsprofil (Säulen Mo–So, Ø gegen Ziel, `BEWERTUNG`) · Routinenquote (gestapelter Balken erfüllt/verpasst/entschuldigt) · **Rang** (§5.3) | `anModKonsistenz`, `rangDiagrammHtml` |
| 2 | `matrixfaktor` | §8.1 | §8.1 | §8.1 | neu |
| 2 | `readiness` | Akku am Start (x) gegen Tagesscore (y): Punktewolke + Trendlinie + Quadranten-Ton, heute weißer Punkt | Zusammenhang (schwach/mittel/stark = |r| < 0,3 / < 0,6 / ≥ 0,6) · Akku heute · Score-Differenz Akku ≥ 70 % vs. < 50 % | Score je Akku-Band (Balken 0–30/30–50/50–70/70–100 %) | `anModReadiness` |
| 3 | `flow` | Aufgaben-Flow DFM: rein (oben, `GRAU` 55 %) / raus (unten, `BEWERTUNG` gegen Ø raus) je Tag + Netto-Linie `WEISS` | Netto Zeitraum · Ø raus je Tag · Backlog offen | Rein und Raus heute (Stunden) · Durchsatz/Balance · Wochentage · Alter/Durchlaufzeit · Deadline-Treue · Rekorde (alle bestehenden Unterteile von `anModAufgabenFlow` und `stReinRaus`) | `anModAufgabenFlow`, `stReinRaus` |
| 3 | `routinen` | gestapelte Säulen je Tag: erfüllt `GRUEN` · verpasst `ROT` · entschuldigt `GRAU` 50 % | Quote erfüllt · Serie · schwächste Routine | je Routine als Balkenliste (Quote, sortiert aufsteigend) | `anModRoutinenFlow` |
| 4 | `acwr` | Bänder-Verlauf 28 T (ROT >1,5 · GELB 1,3–1,5 · GRUEN 0,8–1,3 · ORANGE <0,8, 14 %), Tageslast als Punktewolke, ACWR-Linie `WEISS`, Schwellen rechts | ACWR · Last 7 T · Ø 28 T je 7 T | Last je Tag (Säulen) | `anModACWR` |
| 5 | `spielShop` | Meilenstein-Zeitstrahl ab jetzt (§5.4) | Konto (`GOLD`) · nächster Kauf (Uhrzeit/Tag) · Rang + Prognose | Rang-Bänder + Prognose (§5.3, gleiche Grafik) · Rang über 8 Wochen · Münzen heute (Balken `GOLD` + Prognose 30 % + Ziel-Marke) · Kulisse (§6.6) · Outfit-Sammlung (`outfitSammlungHtml`, Balken in `BEWERTUNG`) · Shop-Stand je Kategorie (Balkenliste `GOLD`) | `belHeuteNoch`, `belErklommen` |

### 5.3 Rang (Hauptsitz: Detail von `konsistenz`)
- Grafik `rangDiagrammHtml` bleibt in der Logik, neu gezeichnet: Hintergrund-Bänder je Rang in `BEWERTUNG`-Mischung (unter aktuellem Rang ROT→GELB, aktueller GELB, Ziel GELBGRUEN, darüber →GRUEN), 16 %; Tages-P/h als Punktewolke; geglättete Linie `WEISS`; Prognose ab heute gestrichelt `WEISS` 70 %; Schwellen rechts beschriftet „Rn".
- **Historische Kennzahlen** (Grid 2×2 unter der Grafik): Bestwert (`rangBest`) · Rang vor 4 Wochen · **Tage auf aktuellem Rang** (neu: ab 3.5.0 täglichen Rang im Tages-Snapshot speichern, Feld `rang`; Anzeige „seit TT.MM." sobald Daten vorliegen, sonst „sammelt") · **Auf- und Abstiege** in 8 Wochen (aus `belVerlaufDaten().wochen`, Anzahl Wechsel nach oben / nach unten).

### 5.4 Meilenstein-Zeitstrahl (neu)
Waagerechte Achse ab jetzt; Markierungen „heute", „+3 T", „+8 T", „+20 T" (dynamisch: heute, dann Abstände der Meilensteine). Meilensteine:
- **Nächster Kauf**: Kreis `GOLD` r=6, Uhrzeit/Tag aus `shopAnkunftText`-Logik.
- **Nächstes Outfit**: Kreisring `GRUEN`, „Outfit n bei F x".
- **Nächster Rang**: Quadrat gestrichelt `WEISS` (Prognose), Tage aus `rangPrognose`.
- **Nächste Kulisse frei**: Kreis `GOLD` 50 %, Wohlstand-Schwelle §6.2; Zeitpunkt = Rest-Wohlstand ÷ Ø Wohlstand-Zufluss je aktivem Tag (letzte 7).
Beschriftung abwechselnd über/unter der Achse, 10 px Titel + 9 px `GRAU` Zusatz.

### 5.5 Entfällt
Modul „Entwicklung" als eigenes Modul (Inhalte verteilt: Tagespunkte → `leistung`, Rang → `konsistenz`, Konto/Kulisse/Kleidung → `spielShop`). „Rein und Raus" als eigenes Modul (in `flow`). Doppelte Namensgebung: Matrix-Belastung heißt „Belastung heute (Matrix)", ACWR heißt „Belastungssteuerung".

**Abnahme §5:** Jedes der 13 Module hat Hauptdiagramm + 3 KPIs (außer Gruppe 1) und klappt per Tipp aufs Diagramm auf. Alle bisherigen Diagramme sind über ein Detail erreichbar. Beschriftung nach §2.5 in jedem Diagramm.

---

## 6 · Shop + Ausmalen (`renderBelohnung`, `belHeuteNoch`, `belErklommen`, `belShopHtml`) — Vorlagen `mockups/261001_FokusApp_Mockup_Shop-Uebersicht.png`, `shop_malmodus.png`, Prototypen `prototyp/shop_*.html`

### 6.1 Währungen (neu getrennt)
- **Münzen** (`konto()`, `spielLiveZufluss`) kaufen **nur Shop-Objekte** (bestehende Kategorien in `BELOHNUNG`: Fahrzeuge, Dachterrasse/Wohnen, Landschaften/Reisen, Mobilität, Begleiter, Freunde/Soziales). Logik unverändert.
- **Wohlstand** treibt **Farbe und Kulisse**. Die Kulisse hängt **nicht mehr** an ausgegebenen Münzen (`bgStufeAus(ausgabenAnzeige())` entfällt als Kulissen-Quelle).
- `W` = Wohlstand seit Reset 3.5.0 (§9.4) = Summe aller nicht-negativen Punkte-Zuflüsse seit `S.meta.reset35.ts`.

### 6.2 Kulissen-Schwellen und Werte
`S(n) = round(2500 · n^2,3)` (bestehende `bgSchwelle`).
- Kulisse 1 ab Start frei. Kulisse k ≥ 2 **freigeschaltet**, wenn `W ≥ S(k) − S(1)`.
- **Wert** der Kulisse n (n < 10) = `S(n+1) − S(n)`; Kulisse 10 = `S(10) − S(9)`. (Steht als `kulissenwertVorschlag` in `bgNN_felder.json`.)
- **Wechsel** auf Kulisse n+1 erst, wenn Kulisse n **zu 100 % ausgemalt** **und** n+1 freigeschaltet ist. Wechsel mit kurzer Überblendung (600 ms).

### 6.3 Felder, Farben, Töpfe
- Assets je Kulisse in `img/kulissen/` (aus `assets/kulissen_ausmal/` übernehmen, Dateinamen unverändert): `bgNN_farbig.jpg` (ausgemalt), `bgNN_kanten.png` (Kantenmaske), `bgNN_feldkarte.png` (8-Bit, Pixelwert = Feldnummer 1…n), `bgNN_felder.json` (Farben mit Hex, Felder mit `farbe`, `flaechePx`, `anteil`, `bbox`). Basisbild bleibt `img/bgNN.jpg`.
- **Feldpunkte** `p(f) = round(anteil(f) · Wert(Kulisse))`, mindestens 1.
- **Topf-Fassung** `T = round(max p(f) · 1,2)` der aktuellen Kulisse (Einstellung `ausmalen.topfAufschlag` = 1,2).
- **Farbe** = Cluster-Index 0–9 aus der JSON; Anzeige-Hex = `farben[i].hex`.
- **5 Töpfe** `{farbe:null|0..9, punkte:0..T}`. Ein Topf hält genau eine Farbe.

### 6.4 Zufluss und Station
- Die **Auswahlstation** zeigt alle Farben der Kulisse als Kreise 26 px mit der Zahl **offener Felder** dieser Farbe darunter; Farben ohne offenes Feld: 25 % Deckkraft und „✓", nicht wählbar. Gewählte Farbe: weißer Ring 2 px.
- Genau **ein Topf steht unter der Station** (aktiver Topf, groß 56 px, weißer Umriss). Er füllt sich mit **jedem Wohlstand-Zufluss** (gleicher Betrag wie Wohlstand, nur positive Zuflüsse, live bei Uhr anteilig wie die Live-Verteilung 3.4.7) in der gewählten Farbe.
- Ein **leerer** Topf übernimmt beim Unterstellen die gewählte Farbe. Ein Topf mit Farbe kann nur unter **seine** Farbe gestellt werden.
- **Topf voll** (`punkte = T`): Banner (§6.5); der Topf rückt zur Seite; der **nächste leere Topf** rückt automatisch unter die Station, gleiche Farbe bleibt gewählt. Gibt es keinen leeren: Zufluss geht in den **Tank** (farblos, ohne Obergrenze), Avatar in der Statusleiste blinkt (§3).
- Wird ein Topf unter die Station gestellt und der Tank ist > 0, fließt der Tank zuerst in diesen Topf (bis voll).
- **Topf wechseln**: anderen Topf unter die Station (Auswahl-Sheet). **Auskippen**: Topf leeren, Inhalt verfällt, Bestätigungsdialog „Inhalt n P verwerfen?".
- Kulissenwechsel: alle Töpfe leer (`farbe:null, punkte:0`), `T` neu, Station mit neuen Farben, **Tank bleibt**.

### 6.5 Banner „Topf voll"
In-App-Banner oben (über allen Ansichten, nicht über Dialogen): „Gelb ist voll — jetzt ausmalen?" mit Topf-Symbol in der Farbe, Knopf „Ausmalen" und „✕". Antippen öffnet Shop → Malmodus. Die Fokus-Uhr läuft **weiter**. „✕" oder Wischen schließt. Banner verschwindet automatisch nach 8 s. Pro vollem Topf ein Banner.

### 6.6 Übersicht (Shop-Einstieg) — `mockups/261001_FokusApp_Mockup_Shop-Uebersicht.png`
Reihenfolge: **Szene** (Kulisse im aktuellen Ausmal-Stand als Canvas nach §6.8, Avatar `AVATAR_BILDER[outfitHeute()-1]` unten mittig 88 % Höhe, Badges „Outfit n/20" links oben, Konto `GOLD` rechts oben) · **4 KPI-Kacheln** 2×2: Töpfe („n voll · 1 füllt", in Farbe des aktiven Topfs) · Kulisse „x %" + „Kulisse n/10" · Konto `GOLD` · nächster Kauf · Knopf **„🖌 Malmodus öffnen"** (volle Breite, hell) · **Was heute noch geht** (2×2: bis Tagesziel in `diaAmpel`, Münzen bis Abend `GOLD`, nächster Kauf, Outfit n+1 bei F) · **Shop** (je Kategorie Zeile: Objektbild `img/obj-<zone><stufe>.png` 54×44, Name, „Stufe n/12", Balken `GOLD_DUNKEL→GOLD` Konto ÷ Preis, „noch n 🪙 · Ankunft"; Kauf-Knopf wie bisher, wenn Konto ≥ Preis) · **Kulisse** (Kopf „KULISSE n/10 · Name", %, Balken im Verlauf der zwei flächengrößten Farben der Kulisse, Text „x von y Feldern · Kulisse n+1 frei ab W · wechselt, wenn n fertig ist") · **Was ich schon erklommen habe** (2×2: Rang + Bestwert, Kulissen fertig, Shop-Stufen gesamt, Outfits erreicht; Knopf „🖼 Album").
Die Figur-Szene von bisher (`avcard`, `avfx`, Vitalität) wird durch die Szene ersetzt; Vitalität als kleine Zeile unter der Szene behalten.

### 6.7 Malmodus — `mockups/261001_FokusApp_Mockup_Shop-Malmodus.png`
Vollbild-Ansicht im Shop. Reihenfolge: **Auswahlstation** (Kopf „AUSWAHLSTATION · Topf unter <Farbname>" links, „Zahl = offene Felder" rechts; Farbkreise; Töpfe-Reihe: aktiver Topf groß + 4 Töpfe 34 px mit Füllstand in ihrer Farbe + Tank 22×44; Knöpfe „Topf wechseln" (2/3) und „Auskippen" (1/3)) · **Kulisse gezoomt** (Pinch-Zoom 1–4×, Doppeltipp 2,5×, Schwenken; Badge „Zoom x · <Farbe>: n Felder offen"; Felder der Farbe des gewählten Topfs, die offen und bezahlbar sind, werden mit 40 % Weiß aufgehellt) · **Töpfe mit Farbe** (alle Töpfe mit `punkte > 0`, groß, Name + Punkte; gewählter Topf weiß umrandet; Text „Feld kostet n P · danach bleiben m P im Topf") · Knopf „✕ Malmodus schließen".
**Ausmalen:** Tipp auf ein Feld → wenn gewählter Topf `farbe == feld.farbe` und `punkte ≥ p(f)`: Feld wird farbig (Überblendung 400 ms), `p(f)` wird abgezogen, Rest bleibt im Topf. Sonst kurzer Hinweis: „Passt nicht: Feld ist <Farbe>" bzw. „Zu wenig Farbe: n von m P". Ein Feld wird **nur vollständig** gefüllt.

### 6.8 Rendering der Kulisse (Canvas)
Ebene 1: `img/bgNN.jpg` (Original = „blass"). Ebene 2: für jedes gefärbte Feld die Pixel aus `bgNN_farbig.jpg` (Maske aus `feldkarte`). Ebene 3: Kantenpixel aus `bgNN_kanten.png` in `#141418`, **aber nur**, wenn die Feldnummer am Pixel (aus `feldkarte`) **nicht** gefärbt ist. Ergebnis: Kanten verschwinden mit dem Ausmalen. Hit-Test: Feldnummer = `feldkarte`-Pixel an der Tippkoordinate.

### 6.9 Erfolge und Album
Album zeigt zusätzlich fertig ausgemalte Kulissen (farbig) neben den Objekten.

**Abnahme §6:** Zufluss in den aktiven Topf entspricht exakt dem Wohlstand-Zufluss (Test mit 3 Buchungen). Topf nie über `T`. Volles Feld nur bei passender Farbe und genug Punkten. Kanten verschwinden nur am gefärbten Feld. Kulissenwechsel nur bei 100 % + Freischaltung. Münzen unverändert.

---

## 7 · Belohnungsansicht (neu) — Prototyp `prototyp/261001_FokusApp_Prototyp_Belohnungsansicht.html`, Bilder `mockups/261001_FokusApp_Mockup_Belohnung-Start/-Mitte/-Ende.png`

### 7.1 Auslöser
- **Aufgabe ✓**: direkt nach der Matrix-/Akku-Abfrage beim Verlassen.
- **Routine mit Uhr**: beim Pausieren, wenn die Sitzung ≥ 1 Min war (nach der Matrix-Abfrage).
- **Counter**: beim Erreichen seines Tagesziels (`tagesziel`).
- **Jeder Tick** (Counter/Routine ohne Uhr): nur **Kurzform** §7.4.
- Nicht bei: Schlafen, Aufstehen, Tagesabschluss, Tagebuch.

### 7.2 Aufbau und Animation (Reihenfolge, Startzeit ab Öffnen)
Vollbild, dunkel, scrollbar. Kopf: „ERLEDIGT · DFM|PRIVAT · <Matrixfeld>" + Titel.
1. **0,3 s Punkte dieser Karte**: große Zahl zählt hoch (0,9 s, ease-out), Zusatz „+n Abhakbonus"; Balken Tagespunkte vorher → nachher gegen Tagesziel, Verlauf `BLAU_HELL→BLAU` (DFM) bzw. `LILA_HELL→LILA`, Soll-Marke `WEISS`; „vorher → nachher von Ziel".
2. **1,3 s Zeit**: Minuten der Sitzung; Balken Anteil am Tagesplan (Summe `sollMin` im Tagesstrom), Verlauf `#6b6e74→WEISS`; „x % vom Tagesplan · Soll n" (Soll nur bei Aufgaben).
3. **1,9 s Akku**: vorher → nachher (Akku-Einträge), Balken läuft vom alten auf den neuen Wert, Verlauf `ROT→GELB→GRUEN`; „−n % in m Min".
4. **2,5 s Tempo**: P/h der Sitzung gegen `tempoSchnitt`; Balken Verlauf `ORANGE→GELB→GELBGRUEN`, Marke „Tag Ø".
5. **3,7 s Farbe**: Topf in der Farbe des aktiven Topfs, Tropfen fallen (7 Stück, 0,12 s versetzt), Füllstand steigt; „+n Wohlstand · Topf a → b %". Ist der Tank aktiv: Tank statt Topf.
6. **4,6 s Münzen**: Münzen fliegen ins Konto (8 Stück), Konto zählt hoch (`GOLD`); wird ein Kauf möglich: „<Kategorie> jetzt kaufbar".
7. **5,2 s Outfit** (nur bei Stufenwechsel): Szene mit Kulisse + Avatar; altes Outfit blendet aus, neues leuchtet grün auf (0,9 s); Hinweis „Outfit n freigeschaltet" unten in der Szene auf dunklem Grund.
8. **6,6 s Weitere Infos** (2×2): Matrixfaktor ×f · Ist ÷ Soll (nur Aufgaben) · Anteil am Tagesziel · nächster Kauf/Meilenstein näher.
- Fehlt die Grundlage eines Schritts (z. B. kein Outfit-Wechsel, keine Akku-Messung), entfällt er und die folgenden rücken vor.
- **Überspringen**: Doppeltipp irgendwo **oder** Knopf „Weiter" unten (fast volle Breite, 16 px, sticky über der Safe-Area). Überspringen zeigt sofort den Endzustand für 0 s und schließt.
- Alle Balken füllen sich animiert (1,1 s, `cubic-bezier(.2,.8,.2,1)`), Elemente blenden mit 0,45 s ein (von 10 px unten).

### 7.3 Daten
Werte aus den Buchungen dieser Sitzung/dieses Abschlusses (keine Prognosen). Punkte = gebuchte Punkte inkl. Abhakbonus. Wohlstand-/Münz-Zufluss = derselbe Betrag wie gebucht (Münzen 1:1, `streakFaktor()` = 1).

### 7.4 Kurzform (jeder Tick)
≈ 1 s, nicht blockierend: Am Tick-Knopf steigt „+n P" auf; ein farbiger Tropfen fliegt zum Avatar in der Statusleiste, eine Münze zum Konto. Keine Interaktion nötig.

**Abnahme §7:** Auslöser exakt nach 7.1. Doppeltipp und „Weiter" schließen sofort. Fehlende Schritte entfallen ohne Lücke. Fokus-Uhr wird durch die Ansicht nicht verändert.

---

## 8 · Matrixfaktor (Statistik-Modul `matrixfaktor` + Bearbeiten)

### 8.1 Modul
- Hauptdarstellung: je Matrixfeld (Ziel, Werkzeug, Zustand, Ablenkung) ein waagerechter Balken: **Punkte ohne Faktor** als Bahn (`GRAU` 35 %), darüber **Punkte mit Faktor** (Ziel `GRUEN`, Werkzeug `WEISS`, Zustand `ORANGE`, Ablenkung `ROT` — nur in diesem Modul als Feld-Kennung), Faktor rechts „×0,8".
- KPIs: effektiver Ø-Faktor im Zeitraum · Punkte, die der Faktor abgezogen hat · Anteil der Zeit auf Karten mit Faktor < 1,0.
- Detail: Liste aller Karten mit `matrixFaktor(k) ≠ 1,0` im Zeitraum: Titel · Feld · ×Faktor · Minuten · Punkte-Differenz · **✎ Bearbeiten**.
- „Punkte ohne Faktor" = gebuchte Punkte ÷ Matrixfaktor (bei Faktor 0: Minuten × Basisrate × Geld-Faktor).

### 8.2 Bearbeiten
✎ öffnet die bestehende Matrixfeld-Auswahl der Karte (gleiche Funktion wie im Karten-Detail). Neues Feld gilt **ab jetzt** (bereits gebuchte Punkte bleiben). Änderung wird in `matrixfeldAenderungen` protokolliert (§9.2). Darunter ein Link „Faktoren je Feld → Einstellungen" (springt zu `matrixFaktoren` in den Einstellungen). **Kein** eigener Faktor je Karte.

---

## 9 · Datenvertrag 2.1, Ketten, Reset

### 9.1 Export (Vollexport und Tagesabschluss) — neue Felder
```json
"ausmalen": { "kulisse": 1, "gefaerbt": [3,7,12], "toepfe": [{"farbe":3,"punkte":420},{"farbe":null,"punkte":0}],
              "aktiverTopf": 0, "stationFarbe": 3, "tank": 0, "wohlstandSeitReset": 0,
              "freigeschaltetBis": 1, "fertig": [] },
"matrixfeldAenderungen": [ { "karteId":"…", "von":"werkzeug", "nach":"ziel", "ts":"ISO" } ],
"reset35": { "ts":"ISO" },
"tagesketten": [ { "id":"…", "name":"DFM-Fokus 1", "karten":["…","…"] } ]
```
Tages-Snapshot (Historie) bekommt `rang` (Zahl oder null).

### 9.2 Import — neue Bereiche
- `einstellungen.ausmalen`: `{ topfAufschlag:1.2, zoomDoppeltipp:2.5, bannerSek:8 }`.
- `tagesketten`: vollständige Liste (ersetzt Bestand, wie `gruppen`). Eine Karte darf in mehreren Ketten stehen. Die bestehende **Tageskette** (`kette`) bleibt unverändert die Ausführungsreihenfolge; `tagesketten` sind benannte Sichten.
- `korrekturen.ausmalen` nur mit `korrektur:true` (wie `serienFaktor`).

### 9.3 Tagesketten in der App
`S.tagesketten = [{id, name, karten:[karteId…]}]`. Anzeige §4.1.3. Bearbeiten in der App: nicht in 3.5.0 (nur Anzeige/Auswahl).

### 9.4 Einmaliger Reset beim ersten Start von 3.5.0
Vorher automatisches Backup (bestehender Backup-Mechanismus der Sync-Tür). Dann: Münzen/Konto = 0 · Ausgaben = 0 · Wohlstand-Zählung `W` ab 0 (`S.meta.reset35 = {ts}`) · Shop-Stufen aller Kategorien = Startstufe · Kulisse = 1, Ausmalen-Zustand leer · Tank 0. **Unverändert**: Rang, `rangBest`, Outfit-Historie, Historie, Punkte, Karten, Statistik. Einmalig über Flag `S.meta.reset35`.

---

## 10 · Prüfpunkte (Fehler beheben)
1. **Ø Ende < Ø Start** (Statistik „Verhalten", Screenshot zeigte Ø Start 09:51, Ø Ende 10:08): Mittelung der Tagesenden über Mitternacht korrigieren (Enden nach 00:00 als 24+h rechnen, Ausgabe modulo 24).
2. Klick-Handler „Alle/DFM/Privat" und Tagesauswahl des Tagesverlaufs: entfällt im Fokus (Modul wandert in die Statistik); in der Statistik müssen sie funktionieren.
3. Testdateien auf 3.5.0.

## 11 · Abnahme gesamt
- Alle Abnahmen §1–§10 erfüllt, Bericht nach Regel 0.5.
- Sichtprüfung bei 375 px und 430 px Breite, hell/dunkel unverändert dunkel.
- Export enthält §9.1, Import akzeptiert §9.2, Gate prüft Datenvertrag 2.1.

## 12 · Festlegungen (von Pascal mit der Freigabe dieses Auftrags bestätigt)
- **F1** Tick-Knopf (+) bei **Aufgaben** in der Kartenliste (§4.1.7) zählt einen Tick mit `tickMinuten` der Karte, Standard 5 Min, als Zeitbuchung nach den Regeln des Modus `zeit`.
- **F2** ✓ bei **Routinen/Countern** in der Kartenliste markiert die Karte für heute als erledigt (`statusHeute`), Abhakbonus höchstens einmal je Tag (bestehende Regel). Bei Aufgaben unverändert.
- **F3** Diskrete Bewertungsskala §1.4 und Tempopfeil-Schwellen §2.3.
- **F4** `MX_FARBE` entfällt in Diagrammen; Matrixfelder werden über Position/Namen gezeigt (Ausnahme: §8.1).
- **F5** Reset §9.4 lässt Rang und Outfit-Historie unverändert.
- **F6** Kulissen-Fortschrittsbalken im Verlauf der zwei flächengrößten Farben der Kulisse.

## Anhang · Dateien im Paket
- `mockups/`: statusleiste, fokus, statistik_1, statistik_2, beschriftung, shop_uebersicht, shop_malmodus, belohnung_a/b/c (PNG)
- `prototyp/`: belohnungsansicht.html (animiert), shop_uebersicht.html, shop_malmodus.html
- `assets/kulissen_ausmal/`: je Kulisse 01–10 `_farbig.jpg`, `_blass_kanten.jpg` (nur Ansicht), `_kanten.png`, `_feldkarte.png`, `_felder.json`, `_vorschau.jpg`; `alle_kulissen_uebersicht.jpg`; `erzeugung_segall.py` (Erzeugungsskript, nicht ausführen)
- `261001_FokusApp_Gedaechtnis_Visualisierung.md`
